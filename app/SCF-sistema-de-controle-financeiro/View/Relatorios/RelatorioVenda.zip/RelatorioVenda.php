<?php 
include '../../config/session.php';
include_once '../../Model/Database/CmdSql.php';
require '../../kint/Kint.class.php';

$result = null;
if(isset($_POST['seach'])){
    
$dataIni = $_POST['txtDataIni'];
$dataFim = $_POST['txtDataFim'];
$idCliente = $_POST['IdCliente'];

$ePesquisa = $_POST['ePesquisa'];

$sql = " SELECT s.CorSaco, s.TamanhoSaco, v.idVenda, v.IdSaco, v.DataVenda, c.Nome, v.Quantidade, v.ValorUnitario, v.ValorTotal, c.idCliente
FROM venda v
INNER JOIN cliente c ON v.ClienteId = c.idCliente
INNER JOIN sacoplastico s ON s.IdSaco = v.IdSaco
WHERE 1 ";


if($idCliente !="0"){
$sql.= " AND c.idCliente ='$idCliente'";


}

if($dataIni != "")
{ $dataIni = implode("-",array_reverse(explode("/",$dataIni))); 
  $sql.= "  AND v.DataVenda >='$dataIni'";
}

if($dataFim != "")
{$dataFim = implode("-",array_reverse(explode("/",$dataFim))); 
 $sql .="  AND v.DataVenda <='$dataFim'";
}

$oPessit = new CmdSql();

$q = $oPessit->query($sql);
$result = $q->fetchAll(PDO::FETCH_OBJ);

}


//d($sql);

?>


<!DOCTYPE html>
<html lang="en" class="translated-ltr"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="./bootstrap-3/assets/ico/favicon.png">

    <title>SCF - Compra</title>

    <!-- Importa o Bootstrap core CSS -->
    <link href="../Front_end/bootstrap-3/dist/css/bootstrap.css" rel="stylesheet">

    <!-- TODAS AS P�?GINAS QUE TIVEREM RODAPÉ E MENU SUPERIOR, TER�? QUE TER ESSAS IMPORTAÇÕES. É UM CSS INDIVIDUAL. -->
    <link href="../Front_end/bootstrap-3/css_individuais/navbar-fixed-top.css" rel="stylesheet">
    <link href="../Front_end/bootstrap-3/css_individuais/sticky-footer-navbar.css" rel="stylesheet">
	

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="../../assets/js/html5shiv.js"></script>
      <script src="../../assets/js/respond.min.js"></script>
    <![endif]-->
  <link type="text/css" rel="stylesheet" charset="UTF-8" href="http://translate.googleapis.com/translate_static/css/translateelement.css"><script type="text/javascript" charset="UTF-8" src="http://translate.googleapis.com/translate_static/js/element/main_pt-BR.js"></script><script type="text/javascript" charset="UTF-8" src="http://translate.googleapis.com/translate_static/js/element/17/element_main.js"></script></head>

  <body>
      

  <?php  include'../MasterPages/menu1.php';?>
      
      
	<!-- Final do menu:Fixed navbar -->
	
<div id="wrap"> 
    <div class="container" style="width: 900px;">
        
        
<div class="panel-group" id="accordion" >
  <div class="panel panel-primary" > 
    <div class="list-group">
      <h4 class="panel-title">
        <a class="list-group-item active" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
          Filtro
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in">
      <div class="panel-body">
          <form role="form" class="form-horizontal" action="./RelatorioVenda.php" method="post" >
 <input type="hidden" name="ePesquisa"  value="true" />         
<div class="form-group">
              <smal>
              
                            <div class="col-md-3">
                                    <label for="DateVenda">Data inicial</label>
                                    <input type="date" class="form-control" name="txtDataIni" id="DateVenda">
				</div>
                            <div class="col-md-3">
                                    <label for="DateVenda">Data final</label>
                                    <input type="date" class="form-control" name="txtDataFim" id="DateVenda">
				</div>
                  
                  
                  
                  
                  
                  <div class="col-md-3">
                            <label for="txtQuant">Nome  Do  Cliente </label>
                              <select name="IdCliente" class="form-control" id="IdCliente">
                                     <option value="0">---</option>
                                  <?php  $oPessit1= new CmdSql();
                               
                               foreach($oPessit1->listAllCliente() as $linha ){?> 
                                   
                            
                               <option value="<?php echo $linha->idCliente; ?>"><?php echo $linha->Nome; ?></option> 
                              
                                    <?php }?>       
                               
                              </select>
                            </div>
                   <div class="col-md-3" style="margin-top: 21px;">
                       <center>
                   <button class="btn btn-primary prefix_10 "  type="submit" name="seach"  value="" ><span class="glyphicon glyphicon-filter" style="margin-right: 5px;"></span>Filtrar</button> </div>
       </center>
             </small>
         </div>
     </form>
     
      
      
      
      
      </div>
    </div>
  </div>

 </div><!-- fim div acordeon-->
    
<?php  if (isset($ePesquisa)){ ?>             
<div class="panel panel-primary" style="margin-top: 10px;">
  <!-- Default panel contents -->
<div class="panel-heading"><center>Resultado</center></div>
<!-- Table -->


<table class=" table table-condensed">
  <tr class="warning">
    <td><b>Cliente</b></td>
    <td><b>Material</b></td>
    <td><b>Data da Venda</b></td>
    <td><b>Quantidade</b></td>
    <td><b>Valor unitario</b></td>
    <td><b>Valor Total</b></td>
    </tr>
    
    <?php  foreach($result as $linha){ ?>
   
    <tr class="warning">
    <td><?php echo$linha->Nome?></td>
    <td><?php echo"Saco".$linha->CorSaco." - ".$linha->TamanhoSaco?></td>
    
    <td><?php echo$linha->DataVenda;?></td>
     <td><?php echo$linha->Quantidade;?></td>
     
      <td><?php echo$linha->ValorUnitario;?></td>
      <td><?php echo$linha->ValorTotal;?></td>
    </tr>
    
    
<?php   }?>
    
    
    
</table>

                       
</div>
<?php   } ?>             
                 
                 </div> <!-- /container -->
</div>

    

<!-- Inicio do rodapé -->
    <?php  include'../MasterPages/footer.php';?>
	<!-- Final do rodapé -->
	
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   <script src="../Front_end/bootstrap-3/assets/js/jquery.js"></script>
    <script src="../Front_end/bootstrap-3/dist/js/bootstrap.js"></script><div id="goog-gt-tt" class="goog-tooltip skiptranslate" dir="ltr" style="visibility: hidden; left: 632px; top: 218px; display: none;"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.google.com/images/icons/product/translate-32.png" width="20" height="20"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texto original</h1></div><div class="middle" style="padding: 8px;"><div class="original-text">This example is a quick exercise to illustrate how the default, static and fixed to top navbar work.</div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Sugira uma tradução melhor</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none; opacity: 0;"></div></div>
  

</body></html>		